from typing import ItemsView
from django.urls import include, path

from userapp import views

urlpatterns = [
    # path('', views.index),
    # path('dashboard/',views.dashboard),
    
]