from django.core.checks.messages import Error
from django.http.response import HttpResponse
from django.conf import settings
from django.shortcuts import redirect, render
from django.contrib import messages
from userapp.models import transcations, userapp,otpauth,balance
from django.core.mail import send_mail
from django.db.models import Q
import math
import random



# ------------------------------------WELCOME PAGE ------------------------------------------------------#
def index(request):
    messages.success(request,"Welcome to the User wallet")
    return render(request,'index.html')


#------------------------------------DASHBOARD PAGE -----------------------------------------------------#
def dash(request):
        if request.session.get('loggedin',False)==False:
            messages.success(request,"You need to sign in first!")
            return redirect('/signin')
        messages.success(request,"Welcome to dashboard!")
        user_id=request.session['user_id']
        user_obj=userapp.objects.get(user_id=user_id)
        balance_obj=balance.objects.get(user_id=user_obj)
        # e = userapp.objects.select_related().get(user_id=user_id)
        
        # print(e.balance)
      
        context = {'name' : user_obj.username,'balance':balance_obj.balance}
        return render(request,'dash.html',context)

#--------------------------------SIGN-UP PAGE------------------------------------------------------------#
def signup(request):

    print(request.method)
    if request.method == "POST":
        username=request.POST.get('username')
        emailId=request.POST.get('emailId')

        check_user=userapp.objects.filter(emailId=emailId).first()
        if check_user:
            messages.success(request,"User Already Exist")
            return render(request,'register.html')
       
        user_obj=userapp.objects.create(emailId=emailId,username=username)
        balance.objects.create(user_id=user_obj,balance=0)
        request.session['user_id']=user_obj.user_id
        
        subject='Verify your email'
        digits = "0123456789"
        signup_otp = ""
        for i in range(4):
            signup_otp += str(digits[math.floor(random.random() * 10)])    
            # signup_otp = "8888"            #for testing 
        message='Your OTP for email verification is '+signup_otp
       
        from_email= settings.EMAIL_HOST_USER
       
        to_list = [emailId]
      
        send_mail(subject,message,from_email,to_list,fail_silently=True)
        messages.success(request,"OTP sent on your Email!")
        context ={'signupotp' : signup_otp}
        otpauth.objects.create(user_id=user_obj,signup_otp=signup_otp)
        return redirect('/otpverify1',context)
    return render(request,'register.html')


#-------------------------OTP VERIFICATION AFTER SIGN-UP PAGE--------------------------------------------------#   
def otpverify1(request):
    user_id=request.session.get('user_id')

    if request.method == 'POST':
        signup_otp1 = request.POST.get('otp')
        otp_obj = otpauth.objects.get(user_id=user_id)
        print(otp_obj)
    
        if signup_otp1 == otp_obj.signup_otp:

            otp_obj.verified_status=True
            otp_obj.save()
            messages.success(request,"Successfully Registered!")
            return redirect('/signin')
        else:
            messages.error(request,"Invalid OTP,Try Again!")
            return redirect('/otpverify1')

    return render(request,'otp_for_signup.html')
    

#------------------------------------SIGN-IN PAGE--------------------------------------------------------------#
def signin(request):
  
    
    if request.method == "POST":
        emailId=request.POST.get('emailId')
        
        user_obj=userapp.objects.filter(emailId=emailId).first()
        if user_obj is not None:
            otp_obj=otpauth.objects.get(user_id=user_obj)       
            if otp_obj.verified_status==True: 
                
                subject='Verify your account'
                digits = "0123456789"
                signin_otp = ""
                for i in range(4) :
                    signin_otp += str(digits[math.floor(random.random() * 10)])    
                message='Your OTP for Account verification is '+signin_otp
                from_email= settings.EMAIL_HOST_USER
                to_list = [emailId]
                send_mail(subject,message,from_email,to_list,fail_silently=True)
                messages.success(request,"OTP sent on your Email!")
                otp_obj.signin_otp = signin_otp
                otp_obj.save()

                request.session['user_id']=user_obj.user_id
                request.session['emailId']=emailId
               
                return redirect('/otpverify2')
            
            messages.success(request,"Verify your Account!")
            request.session['user_id']=user_obj.user_id
            return redirect('/otpverify1')
        else:
            messages.error(request,"User Not Found")
            return render(request,'login.html')
           
    return render(request,'login.html')

#---------------------------------------OTP VERIFICATION AFTER SIGN IN PAGE-------------------------------------------#    
def otpverify2(request):
    user_id=request.session.get('user_id')
    if request.method == 'POST':
        otp = request.POST.get('otp')
      
        otp_obj = otpauth.objects.filter(user_id=user_id).first()
        print(otp_obj.signin_otp) 
       

        if otp == otp_obj.signin_otp:

            messages.success(request,"Successfully login")
            request.session['user_id']=user_id
            request.session['loggedin']=True

            balance_obj=balance.objects.get(user_id=user_id)      
            request.session['Amount']=balance_obj.balance
            return redirect('/dash')

        messages.success(request,"Invalid OTP, Try again!")

        return redirect('/otpverify2')
    return render(request,'otp_for_signin.html' )
    

#---------------------------------------------ADD MONEY PAGE------------------------------------------------------------------------#
def addmoney(request):
        if request.session.get('loggedin',False)==False:
            messages.success(request,"You need to sign in first!")
            return redirect('/signin')
        #-----------for displying name and balance on add money page-----------------#
        emailId = request.session['emailId']
        user_id=request.session['user_id']
        user_obj=userapp.objects.get(user_id=user_id)           
        balance_obj=balance.objects.get(user_id=user_obj)
        context = {'name' : user_obj.username,'balance':balance_obj.balance}
    
        if request.method == "POST":
          
            Amount=request.POST.get('Amount')
            if int(Amount)>0 and int(Amount)<=10000:
                Inital_balance=balance_obj.balance
                Current_Balance=int(Inital_balance)+int(Amount)
                balance_obj.balance=Current_Balance
                balance_obj.save()
                transcations.objects.create(user_id=user_obj,sender_emailId=emailId,receiver_emailId=emailId,transcation_status="1",Amount=Amount)
                messages.success(request,'Successfully added money to your account')
                return redirect('/addmoney')
            messages.success(request,"Entered Money is Invalid, Try again!")
            return redirect('/addmoney')
        return render(request,'addmoney.html',context=context)
    

#-------------------------------------------------SEND MONEY PAGE------------------------------------------------------------------#
def sendmoney(request):
        if request.session.get('loggedin',False)==False:
            messages.success(request,"You need to sign in first!")
            return redirect('/signin')
        emailId = request.session['emailId']
        user_id = request.session['user_id']

        #-----------------login user-------------------------------------------#
        loginuser_obj=userapp.objects.get(user_id=user_id)
        loginbalance_obj=balance.objects.get(user_id=loginuser_obj)
        context = {'name' : loginuser_obj.username,'balance':loginbalance_obj.balance}
    
        if request.method == "POST":
            receiver_emailId=request.POST.get('emailId')
            Amount=request.POST.get('Amount')
            check_user = userapp.objects.filter(emailId = receiver_emailId).first() 
            
            if check_user is None:
                messages.success(request,'User Not Found')
                return redirect('/sendmoney')

            if check_user.emailId!=emailId:
                # messages.success(request,"You can not send money to youself, Try add money feature")
            
                otp_obj=otpauth.objects.get(user_id=check_user.user_id)
                if otp_obj.verified_status==False:
                    messages.success(request,'User Not Verified')    
            
                if loginbalance_obj.balance==0:
                    messages.success(request,'Zero Balance')
                    return redirect('/sendmoney')
                elif loginbalance_obj.balance>=int(Amount):  
                    transcations.objects.create(user_id=loginuser_obj,sender_emailId=loginuser_obj.emailId,receiver_emailId=receiver_emailId,transcation_status="-1",Amount=Amount)
                    current_balance=loginbalance_obj.balance-int(Amount)
                    loginbalance_obj.balance=current_balance 
                    loginbalance_obj.save()
                    transcations.objects.create(user_id=check_user,sender_emailId=receiver_emailId,receiver_emailId=loginuser_obj.emailId,transcation_status="+2",Amount=Amount)
                    Receiver_obj=balance.objects.get(user_id=check_user)
                    current_balance2=Receiver_obj.balance+int(Amount)
                    Receiver_obj.balance=current_balance2
                    Receiver_obj.save()
                    messages.success(request,'Successfully sent money!')
                    return redirect('/dash')
                   
                messages.success(request,'Not Sufficient balance')
            messages.success(request,"You can not send money to youself, Try add money feature")
    
        return render(request,'sendmoney.html',context=context)
    
#------------------------------------TRANSCATION HISTORY---------------------------------------------------------------------------#
def history(request):
        if request.session.get('loggedin',False)==False:
            messages.success(request,"You need to sign in first!")
            return redirect('/signin')
       
        emailId = request.session['emailId']
        user_id = request.session['user_id']
        user_obj=userapp.objects.get(user_id=user_id)
        balance_obj=balance.objects.get(user_id=user_obj)
        t=transcations.objects.filter(Q(sender_emailId=emailId)).all()
        context = {'name' : user_obj.username,'balance':balance_obj.balance,'t':t,'user_id':user_id}
        
        return render(request,'history.html',context=context)
    

#--------------------------------------LOGOUT--------------------------------------------------------------------------------------#
def logout(request):
    if request.session.get('loggedin',False)==False:
            messages.success(request,"You need to sign in first!")
            return redirect('/signin')
    del request.session['loggedin']
    messages.success(request,'Successfully Logout')
    return redirect('/')

#-------------------------------------------------END-----------------------------------------------------------------------------#