package com.franzoo.requestdto;

public class friendDTO {
		private long userId;

		public friendDTO() {
			super();
			// TODO Auto-generated constructor stub
		}
		public friendDTO(long userId) {
			super();
			this.userId = userId;
			
			
		}
		public long getUserId() {
			return userId;
		}
		public void setUserId(long userId) {
			this.userId = userId;
		}
		
		
		
		
	
}
