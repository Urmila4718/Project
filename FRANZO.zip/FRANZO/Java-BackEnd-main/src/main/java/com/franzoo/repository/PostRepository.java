package com.franzoo.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.franzoo.entities.Postdata;

public interface PostRepository extends JpaRepository<Postdata, Long> {
    @Transactional
    @Modifying
	@Query("UPDATE Postdata p set p.like_count = p.like_count+1 WHERE p.postId = ?1")
	int Likepost(long postId);

	@Query("Select p from Postdata p WHERE p.postId=?1")
	Postdata findByPostId(long postId);

	@Query("Select p from Postdata p WHERE p.userId=?1")
	List<Postdata> findAllById(long userId);

	@Query("Select p from Postdata p WHERE p.userId=?1")
	List<Postdata> fetchPostByUserId(long userId);
    
	@Query("Select p from Postdata p WHERE p.postId=?1")
	List<Postdata> findAllByPostId(long postId);

	@Query("SELECT p from Postdata p ")
	List<Postdata> fetchAllPost(); 
			
	
}
