package com.franzoo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="postdata")
public class Postdata {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long postId;
	
	
	@Column(nullable=true,length=100)
	private long userId;

	@Column(nullable=true)
	private String timestamp;
    
	@Column(nullable=true,length=50)
	private long like_count;
     
	
	@Column(nullable=true,length=100)
	private String post_data;

	
	public long getPostId() {
		return postId;
	}
	public void setPostId(long postId) {
		this.postId = postId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String current_timestamp) {
		this.timestamp = current_timestamp;
	}
	
	public long getLike_count() {
		return like_count;
	}
	public void setLike_count(long like_count) {
		this.like_count = like_count;
	}
	
	public String getPost_data() {
		return post_data;
	}
	public void setPost_data(String post_data) {
		this.post_data = post_data;
	}
	
	/*
	public Postdata(long userId, long postId,String timestamp,  String post_data) {
		super();
		this.postId=postId;
		this.userId=userId;
		this.timestamp=timestamp;
		this.post_data=post_data;
		
	}
  	*/
}

