package com.franzoo.customresponse;

public class CustomResponseForPost {
	private long postId;
	private long userId;
	private String timestamp;
	private long like_count;
	private String post_data;
	private String msg;
	
	public CustomResponseForPost( String msg, long postId, long userId, String post_data, long like_count,String timestamp)
		{
		super();
		this.msg=msg;
		this.postId=postId;
		this.userId=userId;
		this.post_data=post_data;
		this.like_count=like_count;
		this.timestamp=timestamp;
		
	}
	public CustomResponseForPost(long postId, long userId, String post_data, long like_count, String timestamp) {
		super();
		this.postId=postId;
		this.userId=userId;
		this.post_data=post_data;
		this.like_count=like_count;
		this.timestamp=timestamp;
	}
	public long getPostId() {
		return postId;
	}
	public void setPostId(long postId) {
		this.postId = postId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String current_timestamp) {
		this.timestamp = current_timestamp;
	}
	
	public long getLike_count() {
		return like_count;
	}
	public void setLike_count(long like_count) {
		this.like_count = like_count;
	}
	
	public String getPost_data() {
		return post_data;
	}
	public void setPost_data(String post_data) {
		this.post_data = post_data;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

	
}
