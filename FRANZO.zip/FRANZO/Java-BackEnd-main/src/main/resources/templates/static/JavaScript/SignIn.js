var dataparameter="";
function userSignIn(){
	debugger;
	var mobile = document.getElementById('phone').value;
	console.log(mobile);
	var password = document.getElementById('SignInPassword').value;
	console.log(password);
	
	if(mobile == ""){
		console.log("1");
		alert("Enter the valid mobile number");
		
	}
	else if(password == ""){
		console.log("2");
		alert("please enter the password");
		
	}
	
	else {
		console.log("3")
		var signInParams = {
			"userMob" : mobile,
			"password" : password
		};
		var signInURL =  "http://127.0.0.1:8080/signin";
		console.log(signInURL);
		console.log(signInParams);
		$.ajax({
			method : "POST",
			url: signInURL, 
			data:JSON.stringify(signInParams),
			contentType:"application/json",
			dataType : 'json',
			success :
				    function (data) {// success callback function
				    console.log(data);
				    if(data.responseText == "Login Successful"){
					alert("Logged In Successful");
					dataparameter = data;
					localStorage.setItem("Name",dataparameter.name);
				          //  	window.location = "franzoohomepage";
				}
				else{
					//window.location = "franzoohomepage";
				}
				    
				            	},
				            	
				            	
			error : function (data, response) {// success callback function
            //alert(JSON.stringify(data)+" -> "+status);
            console.log("5");
            
            if(data.responseText == "Login Failed"){
				alert("wrong credentials");
				window.location = "sign_in";
} else{
	//window.location = "franzoohomepage";
}

    			
	 }
		});
	}
}

  function onlyNumberKey(evt){
		var code = (evt.which) ? evt.which : evt.keyCode
			if(code>31 && (code<48 || code>57))
				return false;
			return true;
}
