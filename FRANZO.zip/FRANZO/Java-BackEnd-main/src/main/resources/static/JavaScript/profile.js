function userProfile(){
	debugger;
	var name = document.getElementById('name').value;
	console.log(name);
	var friends = document.getElementById('friends').value;
	console.log(friends);
	var location = document.getElementById('location').value;
	console.log(location);
	
	if(name == ""){
		console.log("1");
		alert("Enter the Name");
		
	}
	else if(location == ""){
		console.log("2");
		alert("please enter Location");
		}
		
	else {
		console.log("3")
		var profileParams = {
			"username" : name,
			"friends"  :friends,
			"location" : location
		};
	//	var profileURL =  "http://127.0.0.1:8080/viewprofile";
		console.log(profileURL);
		console.log(profileParams);
		$.ajax({
			method : "GET",
			url: profileURL, 
			data:JSON.stringify(profileURL),
			contentType:"application/json",
			dataType : 'json',
			success :
				    function (data) {// success callback function
				    console.log(data);
					profileparameters = data;
					localStorage.getItem("Name").value;
				//	localStorage.setItem("Location",profileparameters.location).value;
				//	localStorage.setItem("Friends", profileparameters.friends).value;
				            	window.location = "aboutme";
				},
	
			            	
			error : function (data) {// success callback function
            //alert(JSON.stringify(data)+" -> "+status);
            console.log("4");
            
            if(data.responseText == "Invalid data"){
				alert("wrong username");
				window.location = "combine_profile";
} else{
	window.location = "franzoohomepage";
}

    			
	 }
		});
	}
}

  function onlyNumberKey(evt){
		var code = (evt.which) ? evt.which : evt.keyCode
			if(code>31 && (code<48 || code>57))
				return false;
			return true;
}
