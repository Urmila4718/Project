package com.franzoo.customresponse;

public class CustomResponseForSignIn {
	
	private String name;
	
	private String mob;
	
	private String email;

	public CustomResponseForSignIn() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomResponseForSignIn(String name, String mob, String email) {
		super();
		this.name = name;
		this.mob = mob;
		this.email = email;
	}

	@Override
	public String toString() {
		return "CustomResponseForSignIn [name=" + name + ", mob=" + mob + ", email=" + email + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	

}
