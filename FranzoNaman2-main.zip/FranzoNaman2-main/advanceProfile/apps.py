from django.apps import AppConfig


class AdvanceprofileConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'advanceProfile'
